# HamChat2 – bootstrap skeleton

This is a minimal loader + logging scaffold.

## Quick start

```bash
python -m pip install --upgrade pip
# (no external deps needed yet)

python main.py --log-level DEBUG
# Logs go to data/logs/app.log and the console
```

## Layout

- `hamchat/logging_config.py` – Rotating file + console logging, uncaught exception hook.
- `hamchat/settings.py` – JSON settings loader with sane defaults (created on first run).
- `hamchat/paths.py` – Data/logs/settings directories.
- `hamchat/app.py` – CLI args, logging init, boot banner.
- `settings/app.json` – Non-sensitive configuration.
