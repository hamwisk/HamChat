"""HamChat2 package."""
__all__ = ["app", "logging_config", "paths", "settings", "constants"]
from .constants import __version__
