# hamchat/core/session.py
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional
from PyQt6.QtCore import QObject, pyqtSignal
from hamchat.core.settings import Settings

@dataclass
class Preferences:
    theme_variant: str = "dark"          # "light" | "dark"
    spellcheck_enabled: bool = True
    locale: str = "en_GB"

@dataclass
class SessionData:
    user_id: Optional[int] = None
    username: str = "Guest"
    role: str = "guest"                  # "guest" | "user" | "admin"
    runtime_mode: str = "solo"           # "solo" | "snout" | "ham"
    server_url: Optional[str] = None
    prefs: Preferences = Preferences()

class SessionManager(QObject):
    sessionChanged = pyqtSignal(object)   # emits SessionData
    prefsChanged   = pyqtSignal(object)   # emits Preferences

    def __init__(self, settings: Settings, runtime_mode: str, server_url: Optional[str]):
        super().__init__()
        self.settings = settings
        self.current = SessionData(runtime_mode=runtime_mode, server_url=server_url)
        # hydrate guest prefs from app settings
        self.current.prefs.theme_variant    = settings.get("theme_variant", "dark")
        self.current.prefs.spellcheck_enabled = bool(settings.get("spellcheck_enabled", True))
        self.current.prefs.locale           = settings.get("locale", "en_GB")
        self.prefsChanged.emit(self.current.prefs)

    # called after a real login later
    def load_user(self, user_id: int, username: str, role: str, user_prefs: dict):
        self.current.user_id = user_id
        self.current.username = username
        self.current.role = role
        # merge user prefs (fallback to current)
        p = self.current.prefs
        p.theme_variant = user_prefs.get("theme_variant", p.theme_variant)
        p.spellcheck_enabled = user_prefs.get("spellcheck_enabled", p.spellcheck_enabled)
        p.locale = user_prefs.get("locale", p.locale)
        self.sessionChanged.emit(self.current)
        self.prefsChanged.emit(self.current.prefs)

    # unified mutators (persist + signal)
    def set_theme_variant(self, variant: str):
        self.current.prefs.theme_variant = variant
        self.settings.set("theme_variant", variant)
        self.prefsChanged.emit(self.current.prefs)

    def set_spell_enabled(self, on: bool):
        self.current.prefs.spellcheck_enabled = bool(on)
        self.settings.set("spellcheck_enabled", bool(on))
        self.prefsChanged.emit(self.current.prefs)

    def set_locale(self, locale: str):
        self.current.prefs.locale = locale
        self.settings.set("locale", locale)
        self.prefsChanged.emit(self.current.prefs)
