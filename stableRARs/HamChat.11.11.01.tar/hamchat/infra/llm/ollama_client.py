# hamchat/infra/llm/ollama_client.py
from __future__ import annotations
import json, requests
from typing import Iterator, List, Dict
from .base import ModelClient, ChatMessage, StreamEvent

DEFAULT_OLLAMA = "http://127.0.0.1:11434"  # mirrors your registry default

class OllamaClient(ModelClient):
    def __init__(self, base_url: str = DEFAULT_OLLAMA, timeout: int = 30):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def stream_chat(self, *, model: str, messages: List[ChatMessage], options: Dict) -> Iterator[StreamEvent]:
        payload = {
            "model": model,
            "messages": [m.__dict__ for m in messages],
            "stream": True,
            "options": options or {}
        }
        url = f"{self.base_url}/api/chat"
        try:
            with requests.post(url, json=payload, stream=True, timeout=self.timeout) as r:
                r.raise_for_status()
                yield StreamEvent(type="start")
                for line in r.iter_lines(decode_unicode=True):
                    if not line:
                        continue
                    # each line is a JSON object { "message": {"role": "...", "content": "Δ"}, "done": bool, ...}
                    try:
                        obj = json.loads(line)
                    except Exception:
                        continue
                    if obj.get("error"):
                        yield StreamEvent(type="error", error=str(obj["error"]))
                        break
                    msg = (obj.get("message") or {})
                    delta = msg.get("content") or ""
                    if delta:
                        yield StreamEvent(type="delta", text=delta)
                    if obj.get("done"):
                        yield StreamEvent(
                            type="end",
                            finish_reason=(obj.get("done_reason") or None),
                            usage={k: obj.get(k) for k in ("prompt_eval_count", "eval_count", "total_duration")}
                        )
                        break
        except Exception as e:
            yield StreamEvent(type="error", error=str(e))
