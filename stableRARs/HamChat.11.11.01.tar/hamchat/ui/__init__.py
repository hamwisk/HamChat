"""HamChat2 gui."""
__all__ = ["splash", "main_window"]

