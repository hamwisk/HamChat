# hamchat/ui/chat_controller.py
from __future__ import annotations
from typing import Optional, List
from PyQt6.QtCore import QObject, Qt
from hamchat.infra.llm.thread_broker import ThreadBroker
from hamchat.infra.llm.base import ChatMessage
from hamchat.infra.llm.backend_adapter import make_stream_func_from_client

class ChatController(QObject):
    def __init__(self, chat_display, model_client, *, model_name: str, parent: Optional[QObject] = None):
        super().__init__(parent)
        self.chat = chat_display
        self.broker = ThreadBroker(self)

        # Simple “messages builder”; swap for real history if you like
        def _build_messages(prompt: str) -> List[ChatMessage]:
            return [ChatMessage(role="user", content=prompt)]

        def _build_options() -> dict:
            return {"temperature": 0.7}

        self.stream_func = make_stream_func_from_client(
            model_client,
            model=model_name,
            build_messages=_build_messages,
            build_options=_build_options,
        )

        # UI → controller
        self.chat.sig_send_text.connect(self._on_user_text, Qt.ConnectionType.QueuedConnection)
        self.chat.sig_stop_requested.connect(self._on_stop, Qt.ConnectionType.QueuedConnection)

        # Broker → UI
        self.broker.job_token.connect(self._on_job_token, Qt.ConnectionType.QueuedConnection)
        self.broker.job_finished.connect(self._on_job_finished, Qt.ConnectionType.QueuedConnection)
        self.broker.job_error.connect(self._on_job_error, Qt.ConnectionType.QueuedConnection)

        self._active_row: Optional[int] = None
        self._active_ticket: int = -1

    # ---------- Slots ----------
    def _on_user_text(self, text: str):
        self._active_row = self.chat.begin_assistant_stream()
        self.chat.set_streaming(True)
        self._active_ticket = self.broker.submit(self.stream_func, text)

    def _on_stop(self):
        self.broker.stop_active()

    def _on_job_token(self, ticket: int, chunk: str):
        if ticket == self._active_ticket and self._active_row is not None:
            self.chat.stream_chunk(self._active_row, chunk)

    def _on_job_finished(self, ticket: int, status: str):
        if ticket == self._active_ticket and self._active_row is not None:
            self.chat.end_assistant_stream(self._active_row)
        self.chat.set_streaming(False)
        self._active_row = None
        self._active_ticket = -1

    def _on_job_error(self, ticket: int, message: str):
        if ticket == self._active_ticket and self._active_row is not None:
            self.chat.stream_chunk(self._active_row, f"\n[error] {message}")
        self.chat.set_streaming(False)
        self._active_row = None
        self._active_ticket = -1
