# hamchat/ui/widgets/chat_panel.py
from __future__ import annotations
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel

class ChatPanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self); lay.setContentsMargins(12,12,12,12); lay.setSpacing(8)
        lay.addWidget(QLabel("<b>Chat Panel</b>"))
        lay.addWidget(QLabel("• Attachments"))
        lay.addWidget(QLabel("• Export / Metadata"))
        lay.addStretch(1)
