# hamchat/ui/widgets/side_panel.py
from __future__ import annotations
import logging
from PyQt6.QtCore import pyqtSignal
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QPushButton, QLabel

log = logging.getLogger("ui.side")

class SidePanel(QWidget):
    sig_open_form = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent); self._build()

    def _build(self):
        lay = QVBoxLayout(self); lay.setContentsMargins(12,12,12,12); lay.setSpacing(8)
        lay.addWidget(QLabel("<b>Side Panel</b>"))
        btn = QPushButton("Open Test Form"); btn.clicked.connect(self.sig_open_form.emit)
        lay.addWidget(btn); lay.addStretch(1)
