#!/bin/bash
set -euo pipefail

# go to this script’s directory
cd "$(dirname "$0")"

# generate a unique local server name each run
SPLASH_NAME="hamchat_splash_$RANDOM$RANDOM"
LOGO_PATH="./data/logo.png"

# verify venv python exists
if [[ ! -x ".venv/bin/python" ]]; then
  echo "⚠️ No venv found. Run:  python3 -m venv .venv && .venv/bin/pip install -r requirements.txt"
  exit 1
fi

# DEV mode: show terminal and keep it open
if [[ "${1:-}" == "--terminal" ]]; then
  # start splash helper (background)
  .venv/bin/python splash_helper.py "$SPLASH_NAME" "$LOGO_PATH" 20000 &
  # choose a terminal that exists on Mint/Ubuntu
  if command -v gnome-terminal >/dev/null 2>&1; then
    SPLASH_NAME="$SPLASH_NAME" gnome-terminal -- bash -lc '.venv/bin/python main.py; echo; echo "Process exited. Press Enter to close..."; read'
  elif command -v x-terminal-emulator >/dev/null 2>&1; then
    x-terminal-emulator -e bash -lc '.venv/bin/python main.py; echo; echo "Process exited. Press Enter to close..."; read'
  else
    # fallback: run inline (no extra terminal)
    exec .venv/bin/python main.py
  fi
  exit $?
fi

# QUIET mode
mkdir -p "${XDG_STATE_HOME:-$HOME/.local/state}/HamChat/data/logs"
log="${XDG_STATE_HOME:-$HOME/.local/state}/HamChat/data.logs/hamchat-$(date +%Y%m%d-%H%M%S).log"

.venv/bin/python splash_helper.py "$SPLASH_NAME" "$LOGO_PATH" 20000 &
nohup env SPLASH_NAME="$SPLASH_NAME" .venv/bin/python main.py >>"$log" 2>&1 < /dev/null &
disown
exit 0
