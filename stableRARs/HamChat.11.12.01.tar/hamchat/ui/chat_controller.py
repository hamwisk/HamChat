# hamchat/ui/chat_controller.py
from __future__ import annotations
from typing import Optional, List
from PyQt6.QtCore import QObject, Qt
from hamchat.infra.llm.thread_broker import ThreadBroker
from hamchat.infra.llm.base import ChatMessage
from hamchat.infra.llm.backend_adapter import make_stream_func_from_client

class ChatController(QObject):
    def __init__(self, chat_display, model_client, *, model_name: str, parent: Optional[QObject] = None):
        super().__init__(parent)
        self.chat = chat_display
        self.broker = ThreadBroker(self)

        # ---- NEW: in-memory session history ----
        self._history: List[ChatMessage] = []
        self._assistant_buf: List[str] = []
        self._max_turns: int = 16   # rolling window; adjust as needed
        # ToDo set the max turns in the session, load it from app.json, or infer it from spec report maybe

        def _build_messages(prompt: str) -> List[ChatMessage]:
            # window: keep last N turns (system messages optional; add if you have them)
            hist = self._history[-self._max_turns*2:]  # user+assistant pairs
            return [*hist, ChatMessage(role="user", content=prompt)]

        def _build_options() -> dict:
            return {"temperature": 0.7}
        # ToDo expose this value to a slider or other suitable QObject in the AI profiles manager and load it from the session

        self.stream_func = make_stream_func_from_client(
            model_client,
            model=model_name,
            build_messages=_build_messages,
            build_options=_build_options,
        )

        # UI → controller
        self.chat.sig_send_text.connect(self._on_user_text, Qt.ConnectionType.QueuedConnection)
        self.chat.sig_stop_requested.connect(self._on_stop, Qt.ConnectionType.QueuedConnection)

        # Broker → UI
        self.broker.job_token.connect(self._on_job_token, Qt.ConnectionType.QueuedConnection)
        self.broker.job_finished.connect(self._on_job_finished, Qt.ConnectionType.QueuedConnection)
        self.broker.job_error.connect(self._on_job_error, Qt.ConnectionType.QueuedConnection)

        self._active_row: Optional[int] = None
        self._active_ticket: int = -1

    # ---------- Slots ----------
    def _on_user_text(self, text: str):
        self._history.append(ChatMessage(role="user", content=text))
        self._assistant_buf = []  # reset buffer for this turn

        self._active_row = self.chat.begin_assistant_stream()
        self.chat.set_streaming(True)
        self._active_ticket = self.broker.submit(self.stream_func, text)

    def _on_stop(self):
        self.broker.stop_active()

    def _on_job_token(self, ticket: int, chunk: str):
        if ticket == self._active_ticket and self._active_row is not None:
            self._assistant_buf.append(chunk)
            self.chat.stream_chunk(self._active_row, chunk)

    def _on_job_finished(self, ticket: int, status: str):
        if ticket == self._active_ticket and self._active_row is not None:
            self.chat.end_assistant_stream(self._active_row)

        # NEW: commit assistant turn iff we received any content
        if self._assistant_buf:
            self._history.append(
                ChatMessage(role="assistant", content="".join(self._assistant_buf))
            )
        self._assistant_buf = []

        self.chat.set_streaming(False)
        self._active_row = None
        self._active_ticket = -1

    def _on_job_error(self, ticket: int, message: str):
        if ticket == self._active_ticket and self._active_row is not None:
            self.chat.stream_chunk(self._active_row, f"\n[error] {message}")
        # Do not record an assistant turn on error (unless you want partials)
        self._assistant_buf = []
        self.chat.set_streaming(False)
        self._active_row = None
        self._active_ticket = -1

    # ---- Optional helpers ----
    def reset_history(self):
        """Call when starting a brand-new conversation (e.g., 'New chat')."""
        self._history.clear()
        self._assistant_buf = []
