# hamchat/ui/main_window.py
from __future__ import annotations
import sys, logging, json
from typing import Optional
from pathlib import Path
from PyQt6.QtCore import Qt, QSize
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QStatusBar, QSplitter, QVBoxLayout, QHBoxLayout,
    QFrame, QLabel, QMessageBox
)

from hamchat.paths import settings_dir
from hamchat.ui.theme import ensure_theme, select_variant, apply_theme, export_qml_tokens
from hamchat.ui.menus import Menus
from hamchat.core.settings import Settings
from hamchat.core.session import SessionManager
from hamchat.core.spell_highlighter import get_available_locales, DictionaryFactory
from .widgets.side_panel import SidePanel
from .widgets.chat_panel import ChatPanel
from .widgets.top_panel import TopPanel
from .widgets.chat_display import ChatDisplay
from .widgets.test_form import TestForm

log = logging.getLogger("ui")

EDGE_WIDTH = 10


class EdgeToggleBar(QFrame):
    def __init__(self, side: str, on_click, parent=None):
        super().__init__(parent)
        self.side = side
        self.on_click = on_click
        self.setFixedWidth(EDGE_WIDTH)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip(f"Toggle {side} panel")
        self.setStyleSheet("background:#30343b;")
    def mousePressEvent(self, ev):
        if ev.button() == Qt.MouseButton.LeftButton and callable(self.on_click):
            self.on_click()


def _hbox(parent):
    w = QFrame(parent)
    lay = QHBoxLayout(w); lay.setContentsMargins(0,0,0,0); lay.setSpacing(0)
    w._lay = lay
    return w

def _vbox(parent):
    w = QFrame(parent)
    lay = QVBoxLayout(w); lay.setContentsMargins(0,0,0,0); lay.setSpacing(0)
    w._lay = lay
    return w

def _settings_path():
    return settings_dir() / "app.json"

def _load_app_cfg() -> dict:
    try:
        return json.loads(_settings_path().read_text("utf-8"))
    except Exception:
        return {}

def _save_app_cfg(cfg: dict):
    p = _settings_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(cfg, indent=2), encoding="utf-8")


class MainWindow(QMainWindow):
    def __init__(
            self, runtime_mode: str,
            server_url: Optional[str] = None,
            parent: Optional[QWidget] = None,
            db_conn: Optional[str] = None,
            db_mode: Optional[str] = None
    ):
        super().__init__(parent)
        self.runtime_mode = runtime_mode
        self.server_url = server_url
        self._db_mode = db_mode
        self._db = db_conn  # ← hold sqlite/sqlcipher connection
        self._models_available = None

        self._build_ui()
        self._wire_signals()

        self._theme = None
        self._variant = "dark"  # default; may be overridden by saved cfg
        self._init_theme()

        # --- Load settings once up front
        app_cfg = Settings(settings_dir() / "app.json")
        self.session = SessionManager(app_cfg, self.runtime_mode, self.server_url)
        self.session.prefsChanged.connect(self._apply_prefs)

        self.side_panel.bind_session(self.session)

        # initial apply
        self._apply_prefs(self.session.current.prefs)        # Restore theme variant before first apply

        # Menus now use session getters/setters
        self.menus = Menus(
            menubar=self.menuBar(),
            get_spell_enabled=lambda: self.session.current.prefs.spellcheck_enabled,
            get_locale=lambda: self.session.current.prefs.locale,
            get_locales=lambda: get_available_locales(),
            toggle_spellcheck=self.session.set_spell_enabled,
            set_spell_locale=self.session.set_locale,
            get_variant=lambda: self.session.current.prefs.theme_variant,
            set_variant=self.session.set_theme_variant,
            new_chat=self._new_chat,
            app_exit=self.close,
            toggle_side_panel=self.toggle_left_panel,
        )
        self.menus.build()
        from hamchat.infra.llm.ollama_client import OllamaClient
        from hamchat.ui.chat_controller import ChatController

        ollama = OllamaClient()  # uses http://127.0.0.1:11434 by default
        self.chat_controller = ChatController(
            self.chat_display,
            model_client=ollama,
            model_name="mistral-nemo",  # pick via your registry if you prefer
            parent=self,
        )

        self._refresh_status()

    def _build_ui(self):
        self.setWindowTitle(f"HamChat — {self.runtime_mode.upper()}")
        self.resize(1200, 800)

        # Central widget with a single horizontal splitter:
        # [ left_container ] | [ chat_area ]
        cw = QWidget(self)
        self.setCentralWidget(cw)
        root = QVBoxLayout(cw); root.setContentsMargins(0,0,0,0); root.setSpacing(0)

        self.outer_split = QSplitter(Qt.Orientation.Horizontal, cw)
        root.addWidget(self.outer_split, 1)

        # --- LEFT CONTAINER: edge bar + side panel
        left_container = _hbox(self.outer_split)
        self.left_edge = EdgeToggleBar("left", self.toggle_left_panel, left_container)
        self.side_panel = SidePanel(left_container)
        self.side_panel.setMinimumWidth(220)
        left_container._lay.addWidget(self.left_edge)
        left_container._lay.addWidget(self.side_panel)

        # --- CHAT AREA (center column): TopPanel + inner splitter(ChatDisplay | right_container)
        chat_area = _vbox(self.outer_split)

        # Top panel lives *inside* chat_area now (won't affect left panel)
        self.top_panel = TopPanel(parent=chat_area)
        chat_area._lay.addWidget(self.top_panel)

        # Inner splitter: [ ChatDisplay ] | [ right_container ]
        self.inner_split = QSplitter(Qt.Orientation.Horizontal, chat_area)
        chat_area._lay.addWidget(self.inner_split, 1)

        # Center chat view
        self.chat_display = ChatDisplay(self.inner_split)
        self.inner_split.addWidget(self.chat_display)

        # Right container: chat_panel + edge bar
        right_container = _hbox(self.inner_split)
        self.chat_panel = ChatPanel(right_container, chat_display=self.chat_display)
        self.chat_panel.setMinimumWidth(260)
        self.right_edge = EdgeToggleBar("right", self.toggle_right_panel, right_container)
        right_container._lay.addWidget(self.chat_panel)
        right_container._lay.addWidget(self.right_edge)
        self.inner_split.addWidget(right_container)

        # Splitter policies / stretch
        # Left rail should not steal stretch; center owns it; right is optional
        self.outer_split.addWidget(left_container)
        self.outer_split.addWidget(chat_area)
        self.outer_split.setCollapsible(0, False)
        self.outer_split.setCollapsible(1, False)
        self.outer_split.setStretchFactor(0, 0)
        self.outer_split.setStretchFactor(1, 1)

        self.inner_split.setCollapsible(0, False)  # chat view
        self.inner_split.setCollapsible(1, False)  # right panel container
        self.inner_split.setStretchFactor(0, 1)
        self.inner_split.setStretchFactor(1, 0)

        # saved widths (panel-only; edge bar is separate)
        self._left_saved_w = 240  # default side panel width
        self._right_saved_w = 260  # default chat panel width

        # remember user drags
        self.outer_split.splitterMoved.connect(self._on_outer_split_moved)
        self.inner_split.splitterMoved.connect(self._on_inner_split_moved)

        # Initial visibility states
        self._left_open = True
        self._right_open = False
        self.chat_panel.setVisible(self._right_open)  # ensure hidden at start
        self._apply_split_sizes(initial=True)

        # Status bar
        self.setStatusBar(QStatusBar(self))

        # One-time object names (so QSS can target cleanly)
        self.side_panel.setObjectName("SidePanel")
        self.chat_panel.setObjectName("ChatPanel")
        self.top_panel.setObjectName("TopPanel")
        self.chat_display.setObjectName("ChatDisplay")
        self.left_edge.setObjectName("EdgeBarLeft")
        self.right_edge.setObjectName("EdgeBarRight")

    def _apply_prefs(self, prefs):
        # theme
        self._variant = prefs.theme_variant
        self._apply_theme_variant()
        # spellcheck
        self._spell_enabled = prefs.spellcheck_enabled
        self._spell_locale = prefs.locale
        self.chat_display.input.set_spell_enabled(self._spell_enabled)
        self.chat_display.input.set_spell_locale(self._spell_locale)

    def _wire_signals(self):
        self.side_panel.sig_open_form.connect(self._open_test_form)
        self.top_panel.sig_closed.connect(self._on_top_closed)

        # NEW: wire side-panel intents to placeholders
        self.side_panel.create_conversation.connect(self._new_chat)
        self.side_panel.open_user_settings.connect(self._open_test_form)   # placeholder
        self.side_panel.open_memory_view.connect(self._open_test_form)     # placeholder
        self.side_panel.open_theme_manager.connect(self._open_test_form)   # placeholder

        # NEW: auth flows
        self.side_panel.request_login.connect(self._open_login_flow)
        self.side_panel.request_logout.connect(self._do_logout)

    def _init_theme(self):
        # Load + merge defaults (writes back if needed) then apply chosen variant
        themes_dir = Path("settings/themes")
        theme = ensure_theme(themes_dir)
        self._theme = theme
        self._apply_theme_variant()  # uses self._variant

    def _apply_theme_variant(self):
        app = QApplication.instance()
        colors = select_variant(self._theme, self._variant)
        apply_theme(app, self, colors)

        qml_tokens = export_qml_tokens(colors)
        self.chat_display.set_qml_tokens(qml_tokens)

    def set_theme(self, theme_dict: dict, variant: str | None = None):
        """
        Optional public setter if you want to inject user theme after login.
        """
        self._theme = theme_dict
        if variant:
            self._variant = variant
        self._apply_theme_variant()
        # Sync the menu toggle if it exists
        if hasattr(self, "act_dark_mode"):
            self.act_dark_mode.setChecked(self._variant == "dark")

    def _toggle_dark_mode(self, checked: bool):
        self._variant = "dark" if checked else "light"
        self._apply_theme_variant()

    def set_models_available(self, count: Optional[int]) -> None:
        self._models_available = count; self._refresh_status()

    def _refresh_status(self) -> None:
        parts = [f"Mode: {self.runtime_mode.upper()}"]
        if self.runtime_mode == "snout" and self.server_url:
            parts.append(f"Server: {self.server_url}")
        if self._db_mode: parts.append(f"DB: {self._db_mode}")
        if isinstance(self._models_available, int): parts.append(f"Models: {self._models_available}")
        self.statusBar().showMessage(" | ".join(parts))

    def toggle_left_panel(self):
        self._left_open = not self._left_open
        # show/hide the actual widget
        self.side_panel.setVisible(self._left_open)
        self._apply_split_sizes()

    def toggle_right_panel(self):
        self._right_open = not self._right_open
        self.chat_panel.setVisible(self._right_open)
        self._apply_split_sizes()

    def _apply_split_sizes(self, initial: bool = False):
        # left container width = edge (always) + panel (if visible)
        left_panel_w = (self._left_saved_w if self._left_open else 0)
        left_w = EDGE_WIDTH + left_panel_w

        # right container width = panel (if visible) + edge (always)
        right_panel_w = (self._right_saved_w if self._right_open else 0)
        right_w = right_panel_w + EDGE_WIDTH

        # Outer: [ left_container | chat_area ]
        outer_total = max(1100, self.width())
        chat_area_w = max(800, outer_total - left_w)
        self.outer_split.setSizes([left_w, chat_area_w])

        # Inner: [ chat_display | right_container ]
        inner_total = chat_area_w
        center_w = max(700, inner_total - right_w)
        self.inner_split.setSizes([center_w, right_w])

    def _on_outer_split_moved(self, pos: int, index: int):
        # Only update saved left width when the panel is open.
        if not self._left_open:
            return
        left_container_w = self.outer_split.sizes()[0]
        # panel width = container minus edge bar
        self._left_saved_w = max(0, left_container_w - EDGE_WIDTH)

    def _on_inner_split_moved(self, pos: int, index: int):
        # Only update saved right width when open.
        if not self._right_open:
            return
        right_container_w = self.inner_split.sizes()[1]
        # panel width = container minus edge bar
        self._right_saved_w = max(0, right_container_w - EDGE_WIDTH)

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        self._apply_split_sizes()

    # -------- NEW auth handlers --------
    def _open_login_flow(self):
        from .widgets.login_form import LoginForm
        admin: bool = self.session.has_admin()
        require_approval = self.session.signup_requires_approval()  # ← session, not file
        # This should be from the session data
        form = LoginForm(admin=admin, signup_requires_approval=require_approval)
        form.sig_close.connect(self.top_panel.close_panel)
        form.submit_admin_setup.connect(self._create_admin)
        form.submit_login.connect(self._login_user)
        form.submit_signup.connect(self._signup_user)
        self.top_panel.open_with(form)

    def _create_admin(self, username: str, password: str):
        from hamchat.db_ops import create_user

        # 1) Write to DB (single source of truth)
        try:
            uid = create_user(
                self._db,
                name=username,
                handle=username.lower(),
                email=None,
                username=username,
                password=password,
                role="admin",
            )
        except Exception as e:
            QMessageBox.critical(self, "Admin setup failed", f"{e}")
            return

        # 2) Reflect in-memory session (emits sessionChanged; updates UI immediately)
        self.session.mark_has_admin(True)  # persists via Settings; no restart needed
        self.session.load_user(uid, username, "admin", {})

        # 3) (Optional) Belt & braces: mirror to app.json too
        try:
            cfg = _load_app_cfg()
            cfg.setdefault("auth", {})["has_admin"] = True
            _save_app_cfg(cfg)
        except Exception as e:
            # Non-fatal: DB+session are already correct
            print(f"Warning: failed to write app.json has_admin flag: {e}")

        self.top_panel.close_panel()

    def _login_user(self, username: str, password: str):
        from hamchat.db_ops import authenticate
        result = authenticate(self._db, username=username, password=password)
        if not result:
            # You can show a QMessageBox here if you want UX feedback
            return
        uid, role, prefs = result
        self.session.load_user(uid, username, role, prefs or {})
        self.top_panel.close_panel()

    def _signup_user(self, username: str, password: str):
        if self.session.signup_requires_approval():
            from hamchat.db_ops import submit_signup_request
            rid = submit_signup_request(
                self._db,
                name=username,
                handle=username.lower(),
                username=username,
                email=None,
                password=password,
            )
            QMessageBox.information(
                self, "Signup request submitted",
                f"Request #{rid} has been sent. An admin will need to approve it before you can log in."
            )
            self.top_panel.close_panel()
            return

        # self-serve path (unchanged)
        from hamchat.db_ops import create_user
        uid = create_user(
            self._db,
            name=username, handle=username.lower(), email=None,
            username=username, password=password, role="user"
        )
        self.session.load_user(uid, username, "user", {})
        self.top_panel.close_panel()

    def _do_logout(self):
        self.session.logout()

    # ----------------- Settings helpers -----------------

    def _open_test_form(self):
        form = TestForm(); form.sig_close.connect(self.top_panel.close_panel); self.top_panel.open_with(form)

    def _on_top_closed(self): pass

    def _new_chat(self):
        # ToDo include a warning
        self.chat_controller.reset_history()
        self.chat_display.clear_messages()
        self.chat_panel.on_new_chat_started()

    def closeEvent(self, ev):
        super().closeEvent(ev)
